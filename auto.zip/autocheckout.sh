#! /bin/sh
set -e

# add something like this into your post-commit:
# /path/to/svn-auto-look-and-checkout "$REPOS" "$REV" "part of repo to be checked out" "where to check out"
#
# Based on svn-auto-checkout by Yann Dirson
# http://ydirson.free.fr/soft/svn/svn-auto-checkout
#
# Hugo Haas - May 2007 - http://larve.net/people/hugo/
# Added call to svnlook to update only the files that are modified by a particular revision
#
# Use it to give remote access to hooks - now on par with cvs, yay ! :)
# HOWTO for an apache-served repository:
# 1. install this script as hooks/bin/svn-auto-checkout in your repository
# 2. register the script as a hook in your post-commit script, by adding the following line:
#    ${REPOS}/hooks/bin/svn-auto-checkout "$REPOS" "$REV" _HOOKS ${REPOS}/hooks
# 3. import the hooks into the svn history:
#    cd hooks
#    sudo -u apache svn import . file:///where/the/repo/is/_HOOKS
# 4. replace the hooks dir with a suitable working copy, including correct ownership:
#    cd /where/the/repo/is
#    sudo -u apache svn co file:///where/the/repo/is/_HOOKS
#    mv hooks hooks.bak
#    mv _HOOKS hooks
# 5. that's all.  Checkout http://your/repo/_HOOKS anywhere, and when your commit will
#    automagically be reflected in the hooks/ dir

REPO="$1"
REV="$2"

# file/dir to auto-checkout ...
REPOPATH="$3"
# ... there
DEST="$4"

PATH=/bin:/usr/bin:/usr/local/bin
export PATH

me=`basename $0`

echo >&2 "$me trace: starting for $REPO r$REV"

if [ "x$REPOPATH" = "x" ]; then
    echo >&2 "$me error: no path inside repository specified"
    exit 1
fi
if [ "x$DEST" = "x" ]; then
    echo >&2 "$me error: no destination directory specified"
    exit 1
fi

if [ -d "$DEST" ]; then
    cd "$DEST"

    # assert working copy
    if svn info >/dev/null ; then
	:
    else
	echo >&2 "$me error: $DEST already exists but is not a svn working copy"
	exit 1
    fi

    # assert URL
    #TODO

    # update changed files to $REV
    svnlook changed -r "$REV" "$REPO" | awk '{ print $2;}' | sed -e "s%^$REPOPATH%./%" | xargs svn update -r "$REV"
else
    svn checkout -r "$REV" "file://$REPO/$REPOPATH" "$DEST"
fi
